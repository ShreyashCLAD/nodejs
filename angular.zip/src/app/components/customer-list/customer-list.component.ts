import { Component, OnInit, ViewChild } from "@angular/core";
import { MatPaginator } from "@angular/material/paginator";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import {SelectionModel} from '@angular/cdk/collections';
import { MatIconModule } from '@angular/material/'
import { CustomerService } from "../../services/customer.service";
import { MatDialog, MatDialogConfig } from "@angular/material";
import { CustomerDetailsComponent } from '../customer-details/customer-details.component';



export interface PeriodicElement {
  firstName: string;
  // position: number;
  dob: string
  lastName: string;
  address:string
  country:string
  city:string
  mobile:number
  email:string
  
}

let ELEMENT_DATA: PeriodicElement[] = [
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
  { firstName: 'Hydrogen', dob: "11-3-2019", lastName: 'H',address:'301 jati colony ran bang ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:895930564},
  { firstName: 'Helium', dob: "11-3-2019", lastName: 'He',address:'b-57 bengali square  ',country:'india',email:'milind.kumar@gmail.com',city:'indore ',mobile:896487456},
 
];

/** Constants used to fill up our data base. */


@Component({
  selector: "app-customer-list",
  templateUrl: "./customer-list.component.html",
  styleUrls: ["./customer-list.component.css"]
})
export class CustomerListComponent implements OnInit {
  displayedColumns: string[] = [ 'firstName','lastName','Address','DOB','email','Mobileno','actions'];


  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  ifSelected: boolean = false;
  dataValues: { position: number; firstName: string; DOB: string; lastName: string; }[];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  selection = new SelectionModel<PeriodicElement>(true, []);
  searchKey: string;
  constructor(private service:CustomerService,private dialog: MatDialog) { 
    console.log(typeof(ELEMENT_DATA))
    this.dataValues =  [{position: 3, firstName: 'Lithium', DOB: "11-3-2019", lastName: 'Li'},
  {position: 4, firstName: 'Beryllium', DOB: "11-3-2019", lastName: 'Be'},
  {position: 5, firstName: 'Boron', DOB: "11-3-2019", lastName: 'B'},
  {position: 6, firstName: 'Carbon', DOB: "11-3-2019", lastName: 'C'},
  {position: 7, firstName: 'Nitrogen', DOB: "11-3-2019", lastName: 'N'},
  {position: 8, firstName: 'Oxygen', DOB: "11-3-2019", lastName: 'O'},
  {position: 9, firstName: 'Fluorine', DOB: "11-3-2019", lastName: 'F'},
  {position: 10, firstName: 'Neon', DOB: "11-3-2019", lastName: 'Ne'},
]
console.log(typeof(this.dataValues))
}
 
  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort; 
}

addNewUser()
{
  console.log("add user");
}

onSearchClear() {
  this.searchKey = "";
  this.applyFilter();
}

applyFilter() {
  this.dataSource.filter = this.searchKey.trim().toLowerCase();
}

onCreate()
{
  this.service.initializeFormGroup();
  const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
  dialogConfig.width = "60%";
  this.dialog.open(CustomerDetailsComponent, dialogConfig);
  
}
  update(row) {
    const dialogConfig = new MatDialogConfig();
    this.service.populateForm(row);
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(CustomerDetailsComponent,dialogConfig);
  }
}
