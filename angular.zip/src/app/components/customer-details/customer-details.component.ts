import { Component, OnInit } from "@angular/core";
import { CustomerService } from "../../services/customer.service";
import { MatDialogRef } from "@angular/material";

@Component({
  selector: "app-customer-details",
  templateUrl: "./customer-details.component.html",
  styleUrls: ["./customer-details.component.css"],
  providers: [CustomerService]
})
export class CustomerDetailsComponent implements OnInit {
  constructor(private service: CustomerService,private dialogRef:MatDialogRef<CustomerDetailsComponent>) {}

  ngOnInit() {
  }

  onClear() {
    console.log("here");
    this.service.form.reset();
    this.service.initializeFormGroup();
  }

  onSubmit() {
    if (this.service.form.valid) {
      console.log(this.service.form.value);
      this.onClose();
    }
  }

  onClose() {
    this.service.form.reset();
    this.service.initializeFormGroup();
    this.dialogRef.close("Thanks for using me!");
    
  }
}

