export class Customer {
  firstName: String;
  lastName: String;
  address: string;
  city: string;
  state: string;
  pin: string;
  phone: number;
  country: string;
  userName: number;
  email: string;
  dob: Date;
  }
