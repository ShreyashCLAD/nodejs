import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Customer } from "./customer.model";
import { FormGroup, FormControl, Validators } from "@angular/forms";


@Injectable()
  
export class CustomerService {
  url: string;
  header: any;
  readonly baseURL = " http://localhost:3000";
  readonly baseURL1 = "http://localhost:3000";

  constructor() {
    // const headerSettings: { [name: string]: string | string[] } = {};
    // this.header = new HttpHeaders(headerSettings);
  }

  form: FormGroup = new FormGroup({
    
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    email: new FormControl('', Validators.email),
    mobile: new FormControl('', [Validators.required, Validators.minLength(8)]),
    address: new FormControl(''),
    dob: new FormControl(''),
    city: new FormControl('', Validators.required),
    // state: new FormControl('', Validators.required),
    country: new FormControl('', Validators.required),
    
  });

  initializeFormGroup() {
    this.form.setValue({
      
      firstName: '',
      lastName: '',
      email: '',
      mobile: '',
      address: '',
      dob: '',
      city: '',
      country: ''
    });
  }



  //post request to add new customer
  // postCustomer(details: Customer) {
  //   const options = {
  //   headers: new HttpHeaders({ "content-type": "application/json" })
  //   };
  //   return this.http.post<Customer[]>(this.baseURL, details, options);
  // }

  // //Get Request to get customer list
  // getCustomerList() {
  // return this.http.get(this.baseURL1);
  // }

  // //Put api for details updation
  // updateCustomer() {
  //   const options = {
  //   headers: new HttpHeaders({ "content-type": "application/json" })
  //   };
  //   const bodyData = {
  //     //
  //     //
  //     //
  //   };
  //   return this.http.put(this.baseURL + `/`, bodyData, options);
  // }

  // //Delete api for remove Customer from list
  // removeCustomer(email: string) {
  //   return this.http.delete(this.baseURL + `/${email}`);
  // }
  populateForm(customer) {
    this.form.setValue(customer);
    console.log(this.form.value);

   
  }
}