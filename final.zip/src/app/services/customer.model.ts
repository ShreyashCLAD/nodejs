export class Customera {
  position: Number
   firstName: String
   DOB: String
   lastName: String
   Address:String
   country:String
   email:String
   city:String
   state:String
   pin:String
   Mobileno:Number
}
