export interface Customer {
    cId : number;
    firstname : string;
    lastname : string;
    date : Date;
    email : string;
    mobileNo: string;
    address: string;
    city : string;
    state : string;
    pin:string;
    country :string
}

